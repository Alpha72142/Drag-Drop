import { PageLoaderModule } from './page-loader.module';

describe('PageLoaderModule', () => {
  let pageHeaderModule: PageLoaderModule;

  beforeEach(() => {
    pageHeaderModule = new PageLoaderModule();
  });

  it('should create an instance', () => {
    expect(pageHeaderModule).toBeTruthy();
  });
});
